import Landingpage from "./LandingPage/landingpage";

export default function Home() {
  return (
    <Landingpage />
  )
}

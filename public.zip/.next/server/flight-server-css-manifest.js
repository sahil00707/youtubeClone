self.__RSC_CSS_MANIFEST={
  "cssImports": {
    "C:\\Users\\TE-302\\live-project\\React-Projects\\youtubeui\\app\\page.tsx": [
      "C:\\Users\\TE-302\\live-project\\React-Projects\\youtubeui\\styles\\landingpage.module.css",
      "C:\\Users\\TE-302\\live-project\\React-Projects\\youtubeui\\Styles\\navbar.module.css",
      "C:\\Users\\TE-302\\live-project\\React-Projects\\youtubeui\\Styles\\sidebar.module.css",
      "C:\\Users\\TE-302\\live-project\\React-Projects\\youtubeui\\Styles\\allvideo.module.css"
    ],
    "C:\\Users\\TE-302\\live-project\\React-Projects\\youtubeui\\app\\layout.tsx": [
      "C:\\Users\\TE-302\\live-project\\React-Projects\\youtubeui\\node_modules\\next\\font\\google\\target.css?{\"path\":\"app\\\\layout.tsx\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}",
      "C:\\Users\\TE-302\\live-project\\React-Projects\\youtubeui\\app\\globals.css"
    ],
    "C:\\Users\\TE-302\\live-project\\React-Projects\\youtubeui\\app\\videoPlayer\\page.tsx": [
      "C:\\Users\\TE-302\\live-project\\React-Projects\\youtubeui\\Styles\\navbar.module.css",
      "C:\\Users\\TE-302\\live-project\\React-Projects\\youtubeui\\styles\\videoplay.module.css",
      "C:\\Users\\TE-302\\live-project\\React-Projects\\youtubeui\\Styles\\allvideo.module.css"
    ]
  },
  "cssModules": {
    "C:\\Users\\TE-302\\live-project\\React-Projects\\youtubeui\\app\\page": [
      "C:\\Users\\TE-302\\live-project\\React-Projects\\youtubeui\\Styles\\navbar.module.css",
      "C:\\Users\\TE-302\\live-project\\React-Projects\\youtubeui\\Styles\\sidebar.module.css",
      "C:\\Users\\TE-302\\live-project\\React-Projects\\youtubeui\\styles\\landingpage.module.css",
      "C:\\Users\\TE-302\\live-project\\React-Projects\\youtubeui\\app\\globals.css",
      "C:\\Users\\TE-302\\live-project\\React-Projects\\youtubeui\\node_modules\\next\\font\\google\\target.css?{\"path\":\"app\\\\layout.tsx\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}",
      "C:\\Users\\TE-302\\live-project\\React-Projects\\youtubeui\\Styles\\allvideo.module.css"
    ],
    "C:\\Users\\TE-302\\live-project\\React-Projects\\youtubeui\\app\\videoPlayer\\page": [
      "C:\\Users\\TE-302\\live-project\\React-Projects\\youtubeui\\styles\\videoplay.module.css",
      "C:\\Users\\TE-302\\live-project\\React-Projects\\youtubeui\\Styles\\allvideo.module.css",
      "C:\\Users\\TE-302\\live-project\\React-Projects\\youtubeui\\Styles\\navbar.module.css",
      "C:\\Users\\TE-302\\live-project\\React-Projects\\youtubeui\\app\\globals.css",
      "C:\\Users\\TE-302\\live-project\\React-Projects\\youtubeui\\node_modules\\next\\font\\google\\target.css?{\"path\":\"app\\\\layout.tsx\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}"
    ]
  }
}